from pyspark import SparkContext, SparkConf
import math
import numpy
from dataAlignment4_par import dataAlignment4_par

def splitRow(row):
    newRow = row.split(' ')
    return newRow

def numberOfFile(idFile):
    nameSplit = idFile.split('New')
    return int(nameSplit[1])

def floatify(array):
    newArray = [ float(x) for x in array ]
    return newArray

def reshapeFun(rowArray):
    nrow = rowArray[0]
    ncol = rowArray[1]
    vecArray = numpy.asarray(rowArray[2::])
    matArray = vecArray.reshape((nrow,ncol))

    return matArray

def buildMatrix(matrixString):
    matrixRows = matrixString.strip().split('\r\n')
    matrixArray = map(splitRow, matrixRows)
    dataArray = map(floatify, matrixArray)

    dataArrayReshape = map(reshapeFun, dataArray)

    return dataArrayReshape

#####################################
# main program                      #
#####################################

if __name__ == "__main__":
    conf = SparkConf().setAppName("PathwayEnrichment")
    sc = SparkContext(conf=conf)
    # path of input folder
    InputPath = "/user/ubuntu/"
    OutputPath = "/user/ubuntu/result/"
    # MZ bin size
    mz_bin_size = 0.1*2# don'e foget to *2
    # RT bin size
    rt_cut = 2
    # DT bin size
    dt_cut = 2.5
    # the whole dataset will be splitted into N pieces
    N = 10
    # if the number of ions in a cluster is larger than ionNumThresh then further split
    ionNumThresh = 10000
    # number of repetitions on boundary
    N_dup = 10

    # results from the first part of program
    mz_min = 248.7972
    mz_max = 1689.3893
    dt_min = 25.926
    dt_max = 198.33
    rt_min = 16.0627096276
    rt_max = 40.070847675
    nfeature = 21
    numFile = 4

    Dif_mz = mz_max-mz_min
    Dif_dt = dt_max-dt_min
    Dif_rt = rt_max-rt_min

    # find m/z bin
    mz_temp = 1/mz_bin_size
    mz_start1 = math.floor(mz_min*mz_temp)/mz_temp
    mz_end1 = math.ceil(mz_max*mz_temp)/mz_temp

    mz_range1 = numpy.arange(mz_start1, mz_end1, mz_bin_size)
    mz_bin = numpy.vstack((mz_range1[:-1],mz_range1[1:])).T

    mz_bin_split = [[  248.6,   405.2], [  405.2,  462.8], [  462.8,   515.2], [  515.2,   561.2],
                     [  561.2,   606.2], [  606.2,   658.6], [  658.6,   722.4], [  722.4,   792. ], [  792.,    888.4], [  888.4,  1689.4]]

    # prepare global variable
    parm1 = dict([('N_dup',N_dup),('mz_bin_split', mz_bin_split), ('mz_bin', mz_bin), ('nfeature', nfeature),('dt_cut', dt_cut),('rt_cut', rt_cut),('mz_bin_size', mz_bin_size),\
                 ('N', N),('numFile', numFile),('ionNumThresh', ionNumThresh),('Dif_mz', Dif_mz),('Dif_dt', Dif_dt),('Dif_rt', Dif_rt)])

    # read in and reorganize files
    FileName_data = sc.wholeTextFiles(InputPath+'*.txt')
    dataLow_all_T2 = FileName_data.map(lambda pair: (numberOfFile(pair[0]), buildMatrix(pair[1])))

    ######.....
    #
    # main matching part

    alignData_all3 = dataLow_all_T2.map(lambda listArray: dataAlignment4_par(listArray,parm1))

    alignData_all3.map(lambda tuple: tuple[0]).saveAsTextFile(OutputPath)
    dataLow_all_T2.unpersist()
